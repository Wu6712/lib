package com.yy.lib.mapper;

import com.yy.lib.entity.Reservation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yao
 * @since 2023-08-18
 */
@Mapper
public interface ReservationMapper extends BaseMapper<Reservation> {

    List<Reservation> findListAll(@Param("pageNum") Integer PageNum,@Param("pageSize") Integer PageSize);

    @Select("select count(*) from reservation")
    Integer selectTotal();

    @Select("select count(*) from reservation")
    int getTotal();

    @Select("select * from reservation where user_id = #{userId}")
    List<Reservation> getOneByUserId(Integer userId);

    @Select("select * from reservation where seat_id = #{seatId}")
    Reservation getOneBySeatId(Integer seatId);

}
