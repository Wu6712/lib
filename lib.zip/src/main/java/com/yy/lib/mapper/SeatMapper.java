package com.yy.lib.mapper;

import com.yy.lib.entity.Seat;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yao
 * @since 2023-08-18
 */
@Mapper
public interface SeatMapper extends BaseMapper<Seat> {

    @Select("select * from seat limit #{pageNum},#{pageSize}")
    List<Seat> selectListSeat(Integer pageNum, Integer pageSize);

    @Select("select count(*) from seat")
    Integer total();

    List<Seat> selectListByFloor(Integer floor);

    int updateStatusById(@Param("id") Integer id, @Param("start") LocalDateTime start, @Param("end") LocalDateTime end);

    @Select("select count(*) from seat where status != 0")
    int getTotal();

    @Select("select * from seat where id = #{id}")
    Seat selectById(Integer id);

    @Select(
            "<script>" +
                "SELECT * FROM seat WHERE id IN" +
                "<foreach item='id' collection='ids' open='(' separator=',' close=')'>" +
                "#{id}" +
                "</foreach>" +
            "</script>"
    )
    List<Seat> selectListInIds(List<Integer> ids);

    @Update("update seat set status = #{status} where id = #{id}")
    int updateById(Integer id, Integer status);

}
