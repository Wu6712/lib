package com.yy.lib.mapper;

import com.yy.lib.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yao
 * @since 2023-08-18
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {

    User selectByUsername(String username);

    List<User> selectByRole(Integer role);

    int deleteOneById(Integer id);

    @Update("update user set score = score - 5 where id = #{id}")
    int dedOfPoints(Integer id);

}
