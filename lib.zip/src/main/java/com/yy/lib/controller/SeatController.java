package com.yy.lib.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yy.lib.entity.Reservation;
import com.yy.lib.mapper.ReservationMapper;
import com.yy.lib.mapper.SeatMapper;
import com.yy.lib.mapper.UserMapper;
import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.yy.lib.entity.Seat;
import com.yy.lib.service.ISeatService;
import com.yy.lib.utils.R;
import com.yy.lib.utils.Result;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yao
 * @since 2023-08-18
 */
@Api(tags = "座位模块")
@RestController
@RequestMapping("/seat")
public class SeatController {
    @Autowired
    private ISeatService seatService;

    @Autowired
    private SeatMapper seatMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private ReservationMapper reservationMapper;

    @Operation(summary = "列表")
    @PostMapping("/list")
    public Result list(@RequestParam Integer pageNum, @RequestParam Integer pageSize) {
        IPage<Seat> iPage = seatService.findList(pageNum, pageSize);
        Map<String, Object> res = new HashMap<>();
        res.put("data", iPage.getRecords());
        res.put("total", iPage.getTotal());
        return R.success("查询成功", res);
    }

    @Operation(summary = "列表2")
    @PostMapping("/list2")
    public Result list2(@RequestParam Integer pageNum, @RequestParam Integer pageSize) {

        IPage<Seat> list2 = seatService.findList2(pageNum, pageSize);

        if (list2 == null) {
            return R.fail("查询失败");
        }

        return R.success(list2);

    }

    @Operation(summary = "列表3")
    @PostMapping("/list3")
    public Result list3(@RequestParam Integer pageNum, @RequestParam Integer pageSize) {
        pageNum = (pageNum - 1)*pageSize;
        List<Seat> list3 = seatService.findList3(pageNum, pageSize);
        Integer total = seatService.total();
        Map<Object, Object> map = new HashMap<>();
        map.put("data",list3);
        map.put("total",total);

        return R.success("查询成功",map);

    }

    @Operation(summary = "更新")
    @PostMapping("/mod")
    public Result mod(@RequestBody Seat seat) {
        return seatService.updateById(seat) ? R.success("更新成功") : R.fail("更新失败");
    }

    @Operation(summary = "删除")
    @PostMapping("/remove")
    public Result remove(Integer id) {
        return seatService.removeById(id) ? R.success("删除成功") : R.fail("删除失败");
    }

    @Operation(summary = "新增")
    @PostMapping("/add")
    public Result add(@RequestBody Seat seat) {
        return seatService.save(seat) ? R.success("新增成功") : R.fail("新增失败");
    }

    @Operation(summary = "批量删除")
    @PostMapping("/remove/batch")
    public Result removeBatch(List<Integer> ids){
        return seatService.removeByIds(ids) ? R.success("批量删除成功") : R.fail("批量删除失败");
    }

    @Operation(summary = "获取一个")
    @GetMapping("/one")
    public Result one(Integer id) {
        return seatService.getById(id) !=null ? R.success("获取成功",seatService.getById(id)) : R.fail("获取失败");
    }

    @Operation(summary = "已预约")
    @PostMapping("/appointment")
    public Result appointment(@RequestParam Integer id){
        return seatService.appointment(id) ? R.success("预约成功") : R.fail("预约失败");
    }

    @Operation(summary = "已取消")
    @PostMapping("/cancelAppointment")
    public Result cancelAppointment(@RequestParam Integer id){
        return seatService.cancelAppointment(id) ? R.success("取消成功") : R.fail("取消失败");
    }

    @Operation(summary = "已开始-签到")
    @PostMapping("/startAppointment")
    public Result startAppointment(@RequestParam Integer id){
        return seatService.startAppointment(id) ? R.success("开始成功") : R.fail("开始失败");
    }

    @Operation(summary = "已完成-签退")
    @PostMapping("/completeAppointment")
    public Result completeAppointment(@RequestParam Integer id){
        return seatService.completeAppointment(id) ? R.success("取消成功") : R.fail("取消失败");
    }

    @Operation(summary = "楼层作为列表")
    @GetMapping("/{floor}")
    public Result getListByFloor(@PathVariable(name = "floor") Integer floor) {

        List<Seat> list = seatService.getListByFloor(floor);

        if (list == null) {
            return R.fail("查询失败");
        }

        return R.success(list);

    }

    @Operation(summary = "修改")
    @PostMapping("/update")
    public Result updateStatus(@RequestParam(name = "id") Integer id,
                               @RequestParam(name = "startTime") String startTime,
                               @RequestParam(name = "endTime") String endTime) {

        System.out.println(id);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        LocalDateTime start = LocalDateTime.parse(startTime, formatter);
        LocalDateTime end = LocalDateTime.parse(endTime, formatter);

        int i = seatService.updateStatusById(id, start, end);

        return R.success("成功");

    }

    @GetMapping("/all")
    public Result getTotal() {

        int total = seatService.getTotal();

        return  R.success(total);
    }

    @Operation(summary = "签到")
    @PostMapping("/sign")
    public Result sign(@RequestParam("seatId") Integer seatId) {

        Seat seat = seatMapper.selectById(seatId);

        LocalDateTime localDateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime currentTime = LocalDateTime.parse(localDateTime.format(formatter), formatter);
        System.out.println(currentTime);

        if(currentTime.isBefore(seat.getStartTime())) {
            return R.fail("还未到签到时间");
        }

        if(currentTime.isAfter(seat.getEndTime())) {
            seatMapper.updateById(seatId, 2);
            Reservation reservation = reservationMapper.getOneBySeatId(seatId);
            userMapper.dedOfPoints(reservation.getUserId());
            return R.fail("已超时");
        }

        seatMapper.updateById(seatId, 3);
        return R.success("签到成功");

    }

}

