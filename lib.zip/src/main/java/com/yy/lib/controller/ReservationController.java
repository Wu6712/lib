package com.yy.lib.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.yy.lib.entity.Seat;
import com.yy.lib.entity.User;
import com.yy.lib.mapper.ReservationMapper;
import com.yy.lib.mapper.SeatMapper;
import com.yy.lib.mapper.UserMapper;
import com.yy.lib.utils.Auth0Jwt;
import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.yy.lib.entity.Reservation;
import com.yy.lib.service.IReservationService;
import com.yy.lib.utils.R;
import com.yy.lib.utils.Result;

import java.util.*;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author yao
 * @since 2023-08-18
 */
@Api(tags = "用户与座位")
@RestController
@RequestMapping("/reservation")
public class ReservationController {
    @Autowired
    private IReservationService reservationService;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private SeatMapper seatMapper;

    @Autowired
    private ReservationMapper reservationMapper;

    @Operation(summary = "列表")
    @PostMapping("/list")
    public Result list(@RequestParam Integer pageNum, @RequestParam Integer pageSize) {
        IPage<Reservation> iPage = reservationService.findList(pageNum, pageSize);
        Map<String, Object> res = new HashMap<>();
        res.put("data", iPage.getRecords());
        res.put("total", iPage.getTotal());
        return R.success("查询成功", res);
    }

    @Operation(summary = "列表")
    @PostMapping("/listAll")
    public Result listAll(@RequestParam Integer pageNum, @RequestParam Integer pageSize) {
        pageNum = (pageNum - 1) * pageSize;
        List<Reservation> data = reservationService.findListAll(pageNum, pageSize);
        Integer total = reservationService.findTotal();
        Map<String, Object> res = new HashMap<>();
        res.put("data", data);
        res.put("total", total);
        return R.success("查询成功", res);
    }

    @Operation(summary = "更新")
    @PostMapping("/mod")
    public Result mod(@RequestBody Reservation reservation) {
        return reservationService.updateById(reservation) ? R.success("更新成功") : R.fail("更新失败");
    }

    @Operation(summary = "删除")
    @PostMapping("/remove")
    public Result remove(Integer id) {
        return reservationService.removeById(id) ? R.success("删除成功") : R.fail("删除失败");
    }

    @Operation(summary = "新增")
    @PostMapping("/add")
    public Result add(@RequestParam(name = "username") String username,
                      @RequestParam(name = "seatId") Integer seatId) {
        User user = userMapper.selectByUsername(username);
        Reservation reservation = new Reservation();
        reservation.setSeatId(seatId);
        reservation.setUserId(user.getId());
        return reservationService.save(reservation) ? R.success("新增成功") : R.fail("新增失败");
    }

    @Operation(summary = "批量删除")
    @PostMapping("/remove/batch")
    public Result removeBatch(List<Integer> ids){
        return reservationService.removeByIds(ids) ? R.success("批量删除成功") : R.fail("批量删除失败");
    }

    @GetMapping("/all")
    public Result getAll() {

        int total = reservationService.getTotal();

        return R.success(total);
    }

    @GetMapping("/{username}")
    public Result listByName(@PathVariable("username") String username) {

        // 获取用户
        User user = userMapper.selectByUsername(username);

        // 获取所有预约记录
        List<Reservation> list = reservationMapper.getOneByUserId(user.getId());

        System.out.println(list);

        // 座位ID
        List<Integer> seatIds = list.stream().map(Reservation::getSeatId).collect(Collectors.toList());
        Collections.reverse(seatIds);

        System.out.println(seatIds);

        List<Seat> seats = seatMapper.selectListInIds(seatIds);

        System.out.println(seats);

        return R.success(seats);

    }



}

