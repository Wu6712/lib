package com.yy.lib.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yy.lib.entity.Seat;
import com.yy.lib.mapper.SeatMapper;
import com.yy.lib.service.ISeatService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yao
 * @since 2023-08-18
 */
@Service
public class SeatServiceImpl extends ServiceImpl<SeatMapper, Seat> implements ISeatService {

    @Autowired
    private SeatMapper seatMapper;

    @Override
    public IPage<Seat> findList(Integer pageNum, Integer pageSize) {
        return this.page(new Page<>(pageNum,pageSize));
    }

    @Override
    public IPage<Seat> findList2(Integer pageNum, Integer pageSize) {
        Page page = new Page<>(pageNum, pageSize);
        IPage<Seat> iPage = seatMapper.selectPage(page, null);
        return iPage;
    }

    @Override
    public boolean appointment(Integer id) {
        UpdateWrapper<Seat> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id",id);
        updateWrapper.set("status",1);
        updateWrapper.setSql("`count` = `count` + 1");
        if(seatMapper.update(null,updateWrapper) == 1){
            return true;
        }else {
            return false;
        }
    }

    @Override
    public boolean cancelAppointment(Integer id) {
        UpdateWrapper<Seat> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id",id);
        updateWrapper.set("status",0);
        if(seatMapper.update(null,updateWrapper) == 1){
            return true;
        }else {
            return false;
        }
    }

    @Override
    public boolean startAppointment(Integer id) {
        UpdateWrapper<Seat> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id",id);
        LocalDateTime now = LocalDateTime.now();
        updateWrapper.set("status",2);
        updateWrapper.set("start_time",now);
        if(seatMapper.update(null,updateWrapper) == 1){
            return true;
        }else {
            return false;
        }
    }

    @Override
    public boolean completeAppointment(Integer id) {
        UpdateWrapper<Seat> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id",id);
        LocalDateTime now = LocalDateTime.now();
        updateWrapper.set("status",3);
        updateWrapper.set("end_time",now);
        if(seatMapper.update(null,updateWrapper) == 1){
            return true;
        }else {
            return false;
        }
    }

    @Override
    public List<Seat> findList3(Integer pageNum, Integer pageSize) {
        return seatMapper.selectListSeat(pageNum, pageSize);
    }

    @Override
    public Integer total() {
        return seatMapper.total();
    }

    @Override
    public List<Seat> getListByFloor(Integer floor) {

//        QueryWrapper<Seat> queryWrapper = new QueryWrapper<>();
//        queryWrapper.eq("floor", floor);
//
//        List<Seat> seats = seatMapper.selectList(queryWrapper);

        List<Seat> seats = seatMapper.selectListByFloor(floor);

        return seats;
    }

    @Override
    public int updateStatusById(Integer id, LocalDateTime start, LocalDateTime end) {

        return seatMapper.updateStatusById(id, start, end);

    }

    @Override
    public int getTotal() {
        return seatMapper.getTotal();
    }
}
