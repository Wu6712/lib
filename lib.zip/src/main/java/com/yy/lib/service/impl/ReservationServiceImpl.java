package com.yy.lib.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yy.lib.entity.Reservation;
import com.yy.lib.mapper.ReservationMapper;
import com.yy.lib.service.IReservationService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author yao
 * @since 2023-08-18
 */
@Service
public class ReservationServiceImpl extends ServiceImpl<ReservationMapper, Reservation> implements IReservationService {

    @Autowired
    private ReservationMapper reservationMapper;

    @Override
    public IPage<Reservation> findList(Integer pageNum, Integer pageSize) {
        return this.page(new Page<>(pageNum,pageSize));
    }

    @Override
    public List<Reservation> findListAll(Integer pageNum, Integer pageSize) {
        return reservationMapper.findListAll(pageNum,pageSize);
    }

    @Override
    public Integer findTotal() {
        return reservationMapper.selectTotal();
    }

    @Override
    public int getTotal() {
        return reservationMapper.getTotal();
    }
}
