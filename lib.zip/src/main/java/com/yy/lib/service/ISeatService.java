package com.yy.lib.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.yy.lib.entity.Seat;
import com.baomidou.mybatisplus.extension.service.IService;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yao
 * @since 2023-08-18
 */
public interface ISeatService extends IService<Seat> {

    IPage<Seat> findList(Integer pageNum, Integer pageSize);

    IPage<Seat> findList2(Integer pageNum, Integer pageSize);

    boolean appointment(Integer id);

    boolean cancelAppointment(Integer id);

    boolean startAppointment(Integer id);

    boolean completeAppointment(Integer id);

    List<Seat> findList3(Integer pageNum, Integer pageSize);

    Integer total();

    List<Seat> getListByFloor(Integer floor);

    int updateStatusById(Integer id, LocalDateTime start, LocalDateTime end);

    int getTotal();
}
