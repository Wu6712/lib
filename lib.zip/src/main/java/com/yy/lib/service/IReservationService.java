package com.yy.lib.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.yy.lib.entity.Reservation;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yao
 * @since 2023-08-18
 */
public interface IReservationService extends IService<Reservation> {

    IPage<Reservation> findList(Integer pageNum, Integer pageSize);

    List<Reservation> findListAll(Integer pageNum, Integer pageSize);

    Integer findTotal();

    int getTotal();
}
