package com.yy.lib.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 *
 * </p>
 *
 * @author yao
 * @since 2023-08-18
 */
@Data
  @EqualsAndHashCode(callSuper = false)
    @ApiModel(value="Seat对象", description="")
public class Seat implements Serializable {

    private static final long serialVersionUID = 1L;

      @ApiModelProperty(value = "id")
        @TableId(value = "id", type = IdType.AUTO)
      private Integer id;

      @ApiModelProperty(value = "行")
      private Integer row;

      @ApiModelProperty(value = "列")
      private String column;

      @ApiModelProperty(value = "楼")
      private Integer floor;

      @ApiModelProperty(value = "区")
      private String area;

      @ApiModelProperty(value = "0，取消，1，预约，2，开始，3，完成")
      private Integer status;

      @ApiModelProperty(value = "预约总次数")
      private Integer total;

    private LocalDateTime startTime;

    private LocalDateTime endTime;


}
