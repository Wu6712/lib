## 1.0.5（2021-05-10）
- 修复 royal 类型无效的bug
- 修复 uni-tag 宽度不自适应的bug
- 新增 uni-tag 支持属性 custom-style 自定义样式
## 1.0.4（2021-02-05）
- 调整为uni_modules目录规范
