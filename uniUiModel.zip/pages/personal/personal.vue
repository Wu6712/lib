<template>
	<view>
		<view class="box" style="display: flex;">
			<!-- <image></image> -->
			<view>
				<u-avatar></u-avatar>
			</view>
			<view style="margin-left: 2vh;">
				<view style="line-height: 98rpx;">{{userdata.username}}</view>
			</view>
			<view style="margin-left: 2vh;">
				<view style="line-height: 98rpx;" v-if="userdata.role == 0">管理员</view>
				<view style="line-height: 98rpx;" v-else-if="userdata.role == 1">老师</view>
				<view style="line-height: 98rpx;" v-else-if="userdata.role == 2">学生</view>
			</view>
		</view>
		<view class="box">
			<u-cell-group>
				<u-cell-item v-for="item in userdata.role == 0?list2:list" :title="item.title" @click="Go(item.link)">
				</u-cell-item>
				<u-cell-item title="预约总数" :arrow="false" :value="total"></u-cell-item>
			</u-cell-group>
		</view>
		<u-button type="error" style="width: 60%;margin-top: 40rpx;" @click="exit">退出登录</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				userdata: {},
				list: [{
						title: '修改密码',
						link:'../changePasswd/changePasswd'
					},
					{
						title: '修改信息',
						link:'../changeInfo/changeInfo'
					},
					{
						title: '查看个人信用分',
						link:'creditScoreManagement/creditScoreManagement'
					}
				],
				list2: [{
						title: '修改密码',
						link:'../changePasswd/changePasswd'
					},
					{
						title: '修改信息',
						link:'../changeInfo/changeInfo'
					},
					{
						title: '查看个人信用分',
						link:'creditScoreManagement/creditScoreManagement'
					},
					{
						title: '老师管理',
						link: '../manageTeacher/manageTeacher'
					},
					{
						title: '学生管理',
						link: '../manageStudent/manageStudent'
					}
				],
				total: 0,
			}
		},
		methods: {
			exit(){
				uni.removeStorageSync('token')
				uni.removeStorageSync('username')
				uni.reLaunch({
					url:"../login/login"
				})
			},
			Go(link){
				uni.navigateTo({
					url:link
				})
			}
		},
		onLoad() {
			this.$request({
				url: '/user/list?pageNum=1&pageSize=10'
			}).then(res => {
				console.log(res);
				res.data.data.map((item) => {
					if (item.username == uni.getStorageSync('username')) {
						this.userdata = item
					}
				})
			})
			this.$request({
				url: '/seat/all'
			}).then(res => {
				console.log(res);
				this.total = res.data
			})
		}
	}
</script>

<style>

</style>
