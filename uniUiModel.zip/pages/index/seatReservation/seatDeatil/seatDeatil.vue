<template>
	<view>
		<view style="width: 100%;height: 100rpx;background-color: #FFFFFF;display: flex;justify-content: space-around;">
			<view style="text-align: center;margin: 20rpx;">
				<image src="../../../../static/单人座位——选座位.png" style="height: 40rpx;" mode="heightFix"></image>
				<view style="font-size: 18rpx;">当前可用</view>
			</view>
			<view style="text-align: center;margin: 20rpx;">
				<image src="../../../../static/单人.png" style="height: 40rpx;" mode="heightFix"></image>
				<view style="font-size: 18rpx;">当前有约</view>
			</view>
		</view>
		<view style="min-height: 80vh;background-color: #FFFFFF;margin-top: 20rpx;">
			<u-grid col="6" :border="false">
				<u-grid-item v-for="(item,index) in dataList" @click="choiceTime(item)">
					<view style="text-align: center;">
						<image :src="item.status==0?'../../../../static/单人座位——选座位.png':'../../../../static/单人.png'"
							style="height: 60rpx;" mode="heightFix">
						</image>
						<view>{{index+1}}</view>
					</view>
				</u-grid-item>
			</u-grid>
		</view>

		<!-- <u-picker 
			:visible="show"
			mode="time"
			@confirm="handleTimeConfirm"
			@cancel="closeTimePicker"
		></u-picker> -->

		<u-popup v-model="show" mode="center" border-radius="20">
			<view style="width: 500rpx;height: 300rpx;padding: 20rpx;">
				<view style="margin: 20rpx 0;">
					<view style="display: flex;">
						<view style="font-weight: 700;line-height: 52rpx;">
							开始时间
						</view>
						<view>
							<!-- <u-input border v-model="startTime" @click="choiceTimePicker" ></u-input> -->
							<view style="border: 1rpx solid #bcbcbc;width: 300rpx;height: 50rpx;border-radius: 10rpx;margin:0 10rpx;" @click="choiceStartTime()">
								{{startTime}}</view>
						</view>
					</view>
				</view>
				<view>
					<view style="display: flex;">
						<view style="font-weight: 700;line-height: 52rpx;">
							结束时间
						</view>
						<view>
							<view style="border: 1rpx solid #bcbcbc;width: 300rpx;height: 50rpx;border-radius: 10rpx;margin:0 10rpx;" @click="choiceEndTime">
								{{endTime}}</view>
						</view>
					</view>
				</view>
				<view style="height: 30rpx;"></view>
				<view style="text-align: center;">
					<u-button type="primary" size="mini" style="margin-top: 10rpx;width: 250rpx;" @click="timeConfirm">确认</u-button>
				</view>

			</view>
		</u-popup>

		<u-picker v-model="startTimePicker" mode="time" :mask="false" @confirm="startTimeC" :params="params"></u-picker>
		<u-picker v-model="endTimePicker" mode="time" :mask="false" @confirm='endTimeC' :params="params"></u-picker>

	</view>
</template>

<script>
	import {
		uDialog,
		uPopup
	} from 'uview-ui';
	export default {
		data() {
			return {
				show: false,
				updateDate: {},
				floor: 0,
				dataList: [],
				startTime: '',
				endTime: '请选择时间',
				startTimePicker: false,
				endTimePicker: false,
				insertStartTime: '',
				insertEndTime: '',
				params :{
					year: true,
					month: true,
					day: true,
					hour: true,
					minute: true,
					second: true
					// province: true,
					// city: true,
					// area: true,
					// timestamp: true, // 1.3.7版本提供
				},
			}
		},
		methods: {
			choiceTime(item) {
				if (item.status != 0) {
					return this.$toast('该位置已被预约')
				}
				this.updateDate = item
				this.show = true
			},
			handleTimeConfirm() {

			},
			closeTimePicker() {
				
			},
			choiceStartTime(){
				this.startTimePicker=true
			},
			choiceEndTime(){
				this.endTimePicker=true
			},
			startTimeC(e){
				console.log(e);
				this.startTime = e.year+'-'+e.month+'-'+e.day+' '+e.hour+':'+e.minute+':'+e.second
				this.insertStartTime = this.startTime
			},
			endTimeC(e){
				console.log(e);
				this.endTime = e.year+'-'+e.month+'-'+e.day+' '+e.hour+':'+e.minute+':'+e.second
				this.insertEndTime = this.endTime
			},
			timeConfirm(){
				let nowTime = new Date(this.startTime)
				let demoTime = new Date(this.endTime)
				function compareTime(time, compareTime) {
				    // console.log(time - compareTime); // 这里计算两个时间之间的毫秒差
					return time - compareTime > 0
				}
				if(compareTime(nowTime, demoTime)){
					this.$toast('请选择正确时间！')
				}else{
					this.$request({
						url: `/seat/update?id=${this.updateDate.id}&startTime=${this.insertStartTime}&endTime=${this.insertEndTime}`,
						method: 'post',
					}).then(res => {
						
						console.log("存入关系表...");
						this.$request({
							url: '/reservation/add?username=' + uni.getStorageSync('username') + '&seatId=' + this.updateDate.id,
							method: 'post',
						}).then(res => {
							console.log(res);
							
							this.$request({
								url: `/seat/${this.floor}`,
								method: 'get'
							}).then(res => {
								this.dataList = res.data
							})
							
						})
						
						this.show = false
						this.$toast(res.message)
					})
					
				}

			}

		},
		onLoad: function(option) {
			uni.setNavigationBarTitle({
				title: `${option.id}楼连廊学习区`
			})
			this.floor = Number(option.id)
			console.log(option);

			this.$request({
				url: `/seat/${this.floor}`,
				method: 'get'
			}).then(res => {
				this.dataList = res.data
			})

			var myDate = new Date;
			var year = myDate.getFullYear(); //获取当前年
			var mon = myDate.getMonth() + 1; //获取当前月
			var date = myDate.getDate(); //获取当前日
			var hours = myDate.getHours(); //获取当前小时
			var minutes = myDate.getMinutes(); //获取当前分钟
			var seconds = myDate.getSeconds(); //获取当前秒
			var now = year + "-" + mon + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
			this.startTime = now


		}
	}
</script>

<style>

</style>