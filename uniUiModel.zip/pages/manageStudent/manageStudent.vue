<template>
	<view>
		<view 
			class="box" 
			v-for="item in dataList" 
			:key="item.id" 
			style="display: flex;justify-content: space-around;align-items: center;">
			<view>姓名: {{item.username}}</view>
			<view>
				信誉分:
				<span v-if="item.score < 60" style="color:red">{{item.score}}</span>
				<span v-else style="color:green">{{item.score}}</span>
			</view>
			<view>
				<u-button type="error" size="mini" @click="deleteUser(item.id)">删除用户</u-button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				dataList: []
			}
		},
		onLoad() {
			this.getUserList()
		},
		methods: {
			deleteUser(id) {
				this.$request({
					url: `/user/${id}`,
					method: 'delete',
				}).then(res => {
					console.log(res);
					if(res.code == 200) {
						this.$toast(res.message)
						this.getUserList()
					}else {
						this.$toast(res.message)
					}
				})
			},
			getUserList() {
				this.$request({
					url: '/user/list/2',
					method: 'get'
				}).then(res => {
					this.dataList = res.data
				})
			}
		}
	}
</script>

<style>
</style>